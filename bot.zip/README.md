# Welcome To EconomyBot <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">
## This EconomyBot was written by 0_0#6666
### Language : JavaScript/NodeJS (Core Lang : EN)
##### Library : Discord.js
###### Framework used : quick.eco by Snowflake Development

##### IN BOTCONFIG.JSON DO NOT CHANGE ANY VARIABLE THE CountChannel var is for if you want to set a channel to count for users if not just leave it blank AND EVERYTHING ELSE IS SELF EPLAINATORY JUST CHANGE THE VALUES INSIDE "" TO MAKE YOUR BOT FUNCTION PROPERLY!
# Links
- 🔗 [Youtube Channel](https://www.youtube.com/channel/UCF9E-xef9jL9QgziZRDHKKQ)
- [Support Server Link](https://discord.gg/ARu4hr6hJw)
# Copyright 
Copyright 2020 © All RIghts are Reserved | If you are using any part of code please give me credits for the same. Thanks

# License
**nginx 2021 all rights reserved**

# Features
- Shop
- Customisable Daily, weekly , search , crime and beg commands (earning)
- Balance
- Leaderboard
- CodeFactor : Easily usable 
## Contribute 
### Feel free to contribute to the repository by forking it and submitting a pull request we would love to have you as a contributor! You mst read through the nginx code of conduct and the (Included) license carefully before submitting a pull request.
#### Node Version Requirement
``12.x or higher``

**NOTE FOR GLITCH HOSTERS 
`` THIS BOT DOES NOT DIE IT SENDS A HEARTBEAT (PING) EVERY 5 MINS TO THE GLITCH PROJECT SO THAT YOUR PROJECT STAYS ALIVE IF IT DOES NOT WORK FOR YOU THEN 
DM ME FOR A SCRIPT THAT PREVENTS THIS JOIN THE SERVER ABOVE AND DM  ME @0_0#6666 THIS MIGHT GET YOUR PROJECT SUSPENDED BUT YOU CAN ALWAYS
MAKE A NEW ONE USING MY TUTORIAL :D``**
``IT WORKS ON REPL.IT PRETTY FINE ITS BEEN TESTED ALREADY``

# Host On Repl.it
[![Use on Repl.it](https://repl.it/badge/github/ZeroDiscord/EconomyBot)](https://repl.it/github/ZeroDiscord/EconomyBot)
# Host On Glitch 
[Click Here to Host On Glitch](https://glitch.com/edit/#!/import/git?url=https://github.com/ZeroDiscord/EconomyBot/)

# Dependencies 
- *Discord.js v12*
- *quick.eco (has a Dev dependency of quick.db and better-sqlite3*)
